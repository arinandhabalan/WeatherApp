const currentYear = ()=>{
    let date =  new Date();
    return date.getFullYear();
}
export default currentYear();