import React from "react";
const Header=()=>{
    return (
        <div className="header-section">
            <h1 className="heading">Climate Predicting App</h1>
        </div>
    )
}
export default Header;